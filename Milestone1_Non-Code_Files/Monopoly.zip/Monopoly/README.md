#Monopoly

SYSC 3110 Fall 2021 Team Project: Monopoly game Version 1.0

Description:
____________

The goal of this team project is to reproduce a simplified version of the classic board of monopoly.The game consists of
features like rolling dice, buying properties, renting properties. When a player rolls dice they move according to the number they rolled. If they land on an unowned property they have an option to purchase it. If the property is owned,
the player has to pay rent to the owner.

The team plans to implement additional features like: hotels, and special properties and squares such as: jail, “Go”, railroad, utility. Also, the ability to play against a number of “AI” players.

Usage:
______

When prompted, enter the name of all the players that will be playing the game.
Commands include roll, info, quit and purchase-related commands.
There is error control -- if you start a game with less than two players, the program tells you that the game was not initialized and quits.
-- if you type an unknown command, the program tells you there is no such command and prompts you again.
Using the quit command ends the program.


Credits:
________

Matthew Belanger,
Tao Lufula,
Nathan MacDiarmid,
Mehedi Mostofa 

Copyright 2021 GROUP 22